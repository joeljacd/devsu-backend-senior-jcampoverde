package com.devsu.hackerearth.backend.account.api;

import java.util.Optional;
import java.util.UUID;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.devsu.hackerearth.backend.account.config.CorrelationFilter;
import com.devsu.hackerearth.backend.account.exception.BusinessException;
import com.devsu.hackerearth.backend.account.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.account.model.dto.ClientResponseDto;

@Component
public class ClientRestClient {

    public static final String HEADER = "X-Correlation-Id";

    private final RestTemplate restTemplate;
    private final String baseUrl;

    @Autowired
    public ClientRestClient(RestTemplate restTemplate, @Value("${client.api.url}") String baseUrl) {
        this.restTemplate = restTemplate;
        this.baseUrl = baseUrl;
    }

    public ClientResponseDto getById(Long id) {
        String correlationId = Optional.ofNullable(MDC.get(CorrelationFilter.MDC_KEY)).orElse(UUID.randomUUID().toString());

        HttpHeaders headers = new HttpHeaders();
        headers.set(HEADER, correlationId);

        try {
            return this.restTemplate.exchange(
                    this.baseUrl + "/{id}",
                    HttpMethod.GET,
                    new HttpEntity<>(headers),
                    ClientResponseDto.class,
                    id).getBody();
        } catch (HttpClientErrorException.NotFound e) {
            throw new ResourceNotFoundException("Cliente", id);
        } catch (HttpClientErrorException e) {
            throw new BusinessException("Error al consultar cliente: " + e.getStatusCode());
        } catch (HttpServerErrorException e) {
            throw new IllegalStateException("El servicio de clientes falló: " + e.getStatusCode(), e);
        } catch (ResourceAccessException e) {
            throw new IllegalStateException("No se pudo conectar con el servicio de clientes", e);
        }
    }
}
