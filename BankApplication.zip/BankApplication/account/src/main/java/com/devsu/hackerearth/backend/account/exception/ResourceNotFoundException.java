package com.devsu.hackerearth.backend.account.exception;

public class ResourceNotFoundException extends RuntimeException {
    
    public ResourceNotFoundException(String resource, Object id){
        super(resource + " no encontrado con id: " + id);
    } 
}
