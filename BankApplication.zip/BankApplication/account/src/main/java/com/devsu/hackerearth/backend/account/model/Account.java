package com.devsu.hackerearth.backend.account.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "account")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Account extends Base {

    @Column(name = "number", nullable = false, length = 50, unique = true)
    private String number;

    @Column(name = "type", nullable = false, length = 1)
    private String type;

    @Column(name = "initial_amount", nullable = false, columnDefinition = "DECIMAL(19,2)")
    private double initialAmount;

    @Column(name = "is_active", nullable = false)
    private boolean isActive;

    @Column(name = "client_id", nullable = false)
    private Long clientId;

}
