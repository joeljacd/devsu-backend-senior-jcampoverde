package com.devsu.hackerearth.backend.account.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "transaction")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Transaction extends Base {

	@Temporal(TemporalType.DATE)
	@Column(name = "date", nullable = false)
	private Date date;

	@Column(name = "type", nullable = false, length = 1)
	private String type;

	@Column(name = "amount", nullable = false, columnDefinition = "DECIMAL(19,2)")
	private double amount;

	@Column(name = "balance", nullable = false, columnDefinition = "DECIMAL(19,2)")
	private double balance;

	@Column(name = "account_id")
	private Long accountId;
}
