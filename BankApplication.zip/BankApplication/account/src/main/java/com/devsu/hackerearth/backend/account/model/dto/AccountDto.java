package com.devsu.hackerearth.backend.account.model.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import com.devsu.hackerearth.backend.account.model.Account;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountDto {

	private Long id;

	@NotBlank(message = "El número de cuenta es obligatorio")
	@Size(max = 50, message = "El tamaño del número de cuenta excede a 50 caracteres.")
	private String number;

	@NotBlank(message = "El tipo es obligatorio")
	@Pattern(regexp = "^[SC]$", message = "El tipo debe ser S (Ahorro) o C (Corriente)")
	private String type;
	
	@NotNull(message = "El valor inicial es obligatorio")
	@Positive(message = "El valor debe ser mayor a cero")
	private double initialAmount;

	@NotNull(message = "El estado es obligatorio")
	private boolean isActive;

	@NotNull(message = "El cliente es obligatorio")
	private Long clientId;

	public static AccountDto from(Account account){
		return new AccountDto(
            account.getId(),
            account.getNumber(),
            account.getType(),
            account.getInitialAmount(),
            account.isActive(),
            account.getClientId()
        );
	}
}
