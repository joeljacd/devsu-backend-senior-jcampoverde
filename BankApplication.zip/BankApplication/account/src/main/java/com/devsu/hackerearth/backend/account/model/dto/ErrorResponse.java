package com.devsu.hackerearth.backend.account.model.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ErrorResponse {
    private final String correlationId;
    private final LocalDateTime timespam;
    private final int status;
    private final String error;
    private final String message;
    private final String path;
    private final List<String> details;
}
