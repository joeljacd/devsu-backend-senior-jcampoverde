package com.devsu.hackerearth.backend.account.model.dto;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PartialAccountDto {

	@NotNull(message = "El estado es obligatorio")
	private boolean isActive;
}
