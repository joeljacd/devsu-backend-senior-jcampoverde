package com.devsu.hackerearth.backend.account.model.dto;

import java.util.Date;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.devsu.hackerearth.backend.account.model.Transaction;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransactionDto {

	private Long id;

	@NotNull(message = "La fecha es obligatorio")
	private Date date;

	@NotBlank(message = "El tipo es obligatorio")
	@Pattern(regexp = "^[RD]$", message = "El tipo debe ser R (Retiro) o D (Deposito)")
	private String type;

	@NotNull(message = "El valor es obligatorio")
	private double amount;

	private double balance;

	@NotNull(message = "La cuenta es obligatorio")
	private Long accountId;

	public static TransactionDto from(Transaction transaction) {
		return new TransactionDto(
				transaction.getId(),
				transaction.getDate(),
				transaction.getType(),
				transaction.getAmount(),
				transaction.getBalance(),
				transaction.getAccountId());
	}
}
