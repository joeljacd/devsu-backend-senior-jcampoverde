package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.api.ClientRestClient;
import com.devsu.hackerearth.backend.account.exception.DuplicateResourceException;
import com.devsu.hackerearth.backend.account.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientResponseDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final ClientRestClient clientRestClient;

    @Autowired
    public AccountServiceImpl(AccountRepository accountRepository,
            ClientRestClient clientRestClient) {
        this.accountRepository = accountRepository;
        this.clientRestClient = clientRestClient;
    }

    @Override
    public List<AccountDto> getAll() {
        // Get all accounts
        return this.accountRepository.findAll().stream().map(AccountDto::from).collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        // Get accounts by id
        return this.accountRepository.findById(id)
                .map(AccountDto::from)
                .orElseThrow(() -> new ResourceNotFoundException("Cuenta", id));
    }

    @Transactional
    @Override
    public AccountDto create(AccountDto accountDto) {
        // Create account
        if (this.accountRepository.existsByNumber(accountDto.getNumber())) {
            throw new DuplicateResourceException("Ya existe una cuenta con el número: " + accountDto.getNumber());
        }

        ClientResponseDto response = this.clientRestClient.getById(accountDto.getClientId());

        Account account = new Account();
        setData(accountDto, account);
        account.setClientId(response.getId());

        return returnResult(account);
    }

    @Transactional
    @Override
    public AccountDto update(AccountDto accountDto) {
        // Update account
        Account account = getAccount(accountDto.getId());
        if (!account.getClientId().equals(accountDto.getClientId())) {
            ClientResponseDto response = this.clientRestClient.getById(accountDto.getClientId());
            account.setClientId(response.getId());
        }

        setData(accountDto, account);

        return returnResult(account);
    }

    @Transactional
    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        // Partial update account
        Account account = getAccount(id);
        account.setActive(partialAccountDto.isActive());

        return returnResult(account);
    }

    @Transactional
    @Override
    public void deleteById(Long id) {
        // Delete account
        getAccount(id);
        this.accountRepository.deleteById(id);
    }

    private void setData(AccountDto accountDto, Account account) {
        account.setNumber(accountDto.getNumber());
        account.setType(accountDto.getType());
        account.setInitialAmount(accountDto.getInitialAmount());
        account.setActive(accountDto.isActive());
    }

    private AccountDto returnResult(Account account) {
        account = this.accountRepository.save(account);

        return AccountDto.from(account);
    }

    private Account getAccount(Long id) {
        Account account = this.accountRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cuenta", id));

        return account;
    }
}
