package com.devsu.hackerearth.backend.account.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.account.api.ClientRestClient;
import com.devsu.hackerearth.backend.account.exception.BusinessException;
import com.devsu.hackerearth.backend.account.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientResponseDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;
    private final ClientRestClient clientRestClient;

    @Autowired
    public TransactionServiceImpl(TransactionRepository transactionRepository,
            AccountRepository accountRepository,
            ClientRestClient clientRestClient) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
        this.clientRestClient = clientRestClient;
    }

    @Override
    public List<TransactionDto> getAll() {
        // Get all transactions
        return this.transactionRepository.findAll().stream().map(TransactionDto::from).collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        // Get transactions by id
        return this.transactionRepository.findById(id)
                .map(TransactionDto::from)
                .orElseThrow(() -> new ResourceNotFoundException("Transacción", id));
    }

    @Transactional
    @Override
    public TransactionDto create(TransactionDto transactionDto) {
        // Create transaction
        Account account = getAccount(transactionDto);

        double value = transactionDto.getAmount();
        if (value == 0) {
            throw new BusinessException("El valor no puede ser cero");
        }

        value = Math.abs(value);
        if ("R".equalsIgnoreCase(transactionDto.getType())) {
            value = -value;
        }

        double newBalance = getNewBalance(account, value);

        Transaction t = new Transaction();
        t.setAccountId(account.getId());
        t.setType(transactionDto.getType());
        t.setAmount(value);
        t.setBalance(newBalance);
        t.setDate(transactionDto.getDate());

        return TransactionDto.from(this.transactionRepository.save(t));
    }

    private double getNewBalance(Account account, double value) {
        double currentBalance = this.transactionRepository.findTopByAccountIdOrderByIdDesc(account.getId())
                .map(Transaction::getBalance)
                .orElse(account.getInitialAmount());

        double newBalance = currentBalance + value;

        if (newBalance < 0)
            throw new BusinessException("Saldo no disponible");

        return newBalance;
    }

    private Account getAccount(TransactionDto transactionDto) {
        Account account = this.accountRepository.findForUpdateById(transactionDto.getAccountId())
                .orElseThrow(() -> new ResourceNotFoundException("Cuenta", transactionDto.getAccountId()));

        if (!account.isActive())
            throw new BusinessException("La cuenta está inactiva");

        return account;
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId,
            Date dateTransactionStart,
            Date dateTransactionEnd) {
        // Report
        if (dateTransactionStart.after(dateTransactionEnd)) {
            throw new BusinessException("La fecha inicial no puede ser mayor a la final");
        }

        ClientResponseDto client = this.clientRestClient.getById(clientId);

        List<BankStatementDto> report = new ArrayList<>();

        for (Account account : this.accountRepository.findByClientId(clientId)) {
            List<Transaction> transactions = this.transactionRepository
                    .findByAccountIdAndDateBetweenOrderByDateAscIdAsc(
                            account.getId(), dateTransactionStart, dateTransactionEnd);

            for (Transaction t : transactions) {
                report.add(new BankStatementDto(
                        t.getDate(),
                        client.getName(),
                        account.getNumber(),
                        account.getType(),
                        account.getInitialAmount(),
                        account.isActive(),
                        t.getType(),
                        t.getAmount(),
                        t.getBalance()));
            }
        }

        return report;
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
        return transactionRepository.findTopByAccountIdOrderByIdDesc(accountId)
                .map(TransactionDto::from)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Transacción para la cuenta", accountId));
    }

}
