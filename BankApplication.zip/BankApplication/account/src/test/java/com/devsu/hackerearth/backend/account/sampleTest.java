package com.devsu.hackerearth.backend.account;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.devsu.hackerearth.backend.account.controller.AccountController;
import com.devsu.hackerearth.backend.account.controller.TransactionController;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.service.AccountService;
import com.devsu.hackerearth.backend.account.service.TransactionService;

@SpringBootTest
public class sampleTest {

	private AccountService accountService = mock(AccountService.class);
	private AccountController accountController = new AccountController(accountService);

	private TransactionService transactionService = mock(TransactionService.class);
	private TransactionController transactionController = new TransactionController(transactionService);

	private AccountDto buildAccount(Long id) {
		AccountDto dto = new AccountDto();
		dto.setId(id);
		dto.setNumber("number");
		dto.setType("savings");

		return dto;
	}

	private TransactionDto buildTransaction(Long id) {
		TransactionDto dto = new TransactionDto();
		dto.setId(id);
		dto.setAccountId(1L);
		dto.setType("D");
		dto.setAmount(100.0);

		return dto;
	}

	@Test
	void createAccountTest() {
		// Arrange
		AccountDto newAccount = new AccountDto(1L, "number", "savings", 0.0, true, 1L);
		AccountDto createdAccount = new AccountDto(1L, "number", "savings", 0.0, true, 1L);
		when(accountService.create(newAccount)).thenReturn(createdAccount);

		// Act
		ResponseEntity<AccountDto> response = accountController.create(newAccount);

		// Assert
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertEquals(createdAccount, response.getBody());
	}

	@Test
	void getAccountTest() {
		AccountDto account = buildAccount(1L);
		when(accountService.getById(1L)).thenReturn(account);

		ResponseEntity<AccountDto> response = accountController.get(1L);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(account, response.getBody());
	}

	@Test
	void updateAccountTest() {
		AccountDto request = buildAccount(null);
		AccountDto updated = buildAccount(1L);
		when(accountService.update(request)).thenReturn(updated);

		ResponseEntity<AccountDto> response = accountController.update(1L, request);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(updated, response.getBody());
	}

	@Test
	void deleteAccountTest() {
		ResponseEntity<Void> response = accountController.delete(1L);

		assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
		verify(accountService).deleteById(1L);
	}

	@Test
	void createTransactionTest() {
		TransactionDto request = buildTransaction(null);
		TransactionDto created = buildTransaction(1L);
		when(transactionService.create(request)).thenReturn(created);

		ResponseEntity<TransactionDto> response = transactionController.create(request);

		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertEquals(created, response.getBody());
	}

	@Test
	void getTransactionTest() {
		TransactionDto transaction = buildTransaction(1L);
		when(transactionService.getById(1L)).thenReturn(transaction);

		ResponseEntity<TransactionDto> response = transactionController.get(1L);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(transaction, response.getBody());
	}

	@Test
	void reportTest() {
		Date start = new Date();
		Date end = new Date();
		List<BankStatementDto> report = Collections.singletonList(new BankStatementDto());
		when(transactionService.getAllByAccountClientIdAndDateBetween(1L, start, end)).thenReturn(report);

		ResponseEntity<List<BankStatementDto>> response = transactionController.report(1L, start, end);

		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(1, response.getBody().size());
	}
}
