package com.devsu.hackerearth.backend.client.exception;

public class BusinessException extends RuntimeException {
    
    public BusinessException(String message){
        super(message);
    } 
}