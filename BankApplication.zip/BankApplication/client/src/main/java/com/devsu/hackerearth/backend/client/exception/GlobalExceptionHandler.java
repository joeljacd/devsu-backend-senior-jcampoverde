package com.devsu.hackerearth.backend.client.exception;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.MDC;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.devsu.hackerearth.backend.client.config.CorrelationFilter;
import com.devsu.hackerearth.backend.client.model.dto.ErrorResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFound(ResourceNotFoundException ex, HttpServletRequest req){
        return build(HttpStatus.NOT_FOUND, ex.getMessage(), req, null);
    }
    
    @ExceptionHandler(DuplicateResourceException.class)
    public ResponseEntity<ErrorResponse> handleDuplicate(DuplicateResourceException ex, HttpServletRequest req){
        return build(HttpStatus.CONFLICT, ex.getMessage(), req, null);
    }

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ErrorResponse> handleBusiness(BusinessException ex, HttpServletRequest req){
        return build(HttpStatus.BAD_REQUEST, ex.getMessage(), req, null);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException ex, HttpServletRequest req){
        List<String> details = ex.getBindingResult().getFieldErrors()
                                    .stream()
                                    .map(m -> m.getField() + ": " + m.getDefaultMessage())
                                    .collect(Collectors.toList());
        
        return build(HttpStatus.BAD_REQUEST, "Datos de entrada inválidos", req, details);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ErrorResponse> hanleIntegrity(DataIntegrityViolationException ex, HttpServletRequest req){
        return build(HttpStatus.CONFLICT, "Violación de integridad de datos", req, null);
    }

    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<ErrorResponse> hanleIllegal(IllegalStateException ex, HttpServletRequest req){
        return build(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor", req, null);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> hanleGeneric(Exception ex, HttpServletRequest req){
        return build(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor", req, null);
    }

    private ResponseEntity<ErrorResponse> build (HttpStatus status,
                                                String message,
                                                HttpServletRequest req,
                                                List<String> details
                                            ){
        ErrorResponse body = ErrorResponse.builder()
                                          .correlationId(MDC.get(CorrelationFilter.MDC_KEY))
                                          .timespam(LocalDateTime.now())
                                          .status(status.value())
                                          .error(status.getReasonPhrase())
                                          .message(message)
                                          .path(req.getRequestURI())
                                          .details(details)
                                          .build();

        return ResponseEntity.status(status).body(body);
    }


}
