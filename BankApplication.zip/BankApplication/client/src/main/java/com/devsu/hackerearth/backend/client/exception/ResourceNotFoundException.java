package com.devsu.hackerearth.backend.client.exception;

public class ResourceNotFoundException extends RuntimeException {
    
    public ResourceNotFoundException(String resource, Object id){
        super(resource + " no encontrado con id: " + id);
    } 
}
