package com.devsu.hackerearth.backend.client.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "client")
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class Client extends Person {

	@Column(name = "password", nullable = false, length = 100)
	private String password;

	@Column(name = "is_active", nullable = false)
	private boolean isActive;
}
