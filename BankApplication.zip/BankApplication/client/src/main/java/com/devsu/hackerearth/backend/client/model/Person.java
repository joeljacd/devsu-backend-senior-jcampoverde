package com.devsu.hackerearth.backend.client.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.Min;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@MappedSuperclass
public class Person extends Base {

	@Column(name = "name", nullable = false, length = 100)
	private String name;

	@Column(name = "dni", nullable = false, unique = true, length = 20)
	private String dni;

	@Column(name = "gender", nullable = false, length = 1)
	private String gender;

	@Min(0)
	@Column(name = "age", nullable = false)
	private int age;

	@Column(name = "address", nullable = false, length = 100)
	private String address;

	@Column(name = "phone", nullable = false, length = 20)
	private String phone;
}
