package com.devsu.hackerearth.backend.client.model.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import com.devsu.hackerearth.backend.client.model.Client;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ClientDto {

	private Long id;

	@NotBlank(message = "El dni es obligatorio")
	@Size(max = 20, message = "El tamaño del dni excede a 100 caracteres.")
	private String dni;

	@NotBlank(message = "El nombre es obligatorio")
	@Size(max = 100, message = "El tamaño del nombre excede a 100 caracteres.")
	private String name;

	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private String password;

	@NotBlank(message = "El genero es obligatorio")
	@Pattern(regexp = "^[MF]$", message = "El género debe ser M o F")
	private String gender;

	@NotNull(message = "La edad es obligatorio")
	@Positive(message = "La edad debe ser mayor a 0")
	private int age;

	@NotBlank(message = "La dirección es obligatorio")
	@Size(max = 100, message = "El tamaño del dirección excede a 100 caracteres.")
	private String address;

	@NotBlank(message = "El teléfono es obligatorio")
	@Size(max = 20, message = "El tamaño del teléfono excede a 20 caracteres.")
	private String phone;

	@NotNull(message = "El estado es obligatorio")
	private boolean isActive;

	public static ClientDto from(Client client) {
		return new ClientDto(client.getId(),
				client.getDni(),
				client.getName(),
				client.getPassword(),
				client.getGender(),
				client.getAge(),
				client.getAddress(),
				client.getPhone(),
				client.isActive());
	}
}
