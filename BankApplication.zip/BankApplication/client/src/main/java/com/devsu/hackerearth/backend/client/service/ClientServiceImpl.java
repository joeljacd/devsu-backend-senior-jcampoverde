package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.client.exception.DuplicateResourceException;
import com.devsu.hackerearth.backend.client.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;
import com.devsu.hackerearth.backend.client.util.PasswordUtil;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Override
	public List<ClientDto> getAll() {
		// Get all clients
		return this.clientRepository.findAll().stream().map(ClientDto::from).collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		// Get clients by id
		return this.clientRepository.findById(id)
				.map(ClientDto::from)
				.orElseThrow(() -> new ResourceNotFoundException("Cliente", id));
	}

	@Transactional
	@Override
	public ClientDto create(ClientDto clientDto) {
		// Create client
		if (this.clientRepository.existsByDni(clientDto.getDni())) {
			throw new DuplicateResourceException("Ya existe un cliente con DNI " + clientDto.getDni());
		}

		Client client = new Client();
		setDataClient(clientDto, client);

		String password = clientDto.getPassword();
		if (password == null || password.trim().isEmpty()) {
			password = PasswordUtil.generatePassword();
		}

		String passwordEncode = PasswordUtil.hash(password);
		client.setPassword(passwordEncode);

		return returnResult(client);
	}

	@Transactional
	@Override
	public ClientDto update(ClientDto clientDto) {
		// Update client
		Client client = getClient(clientDto.getId());

		setDataClient(clientDto, client);

		return returnResult(client);
	}

	@Transactional
	@Override
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
		// Partial update account
		Client client = getClient(id);

		client.setActive(partialClientDto.isActive());

		return returnResult(client);
	}

	@Transactional
	@Override
	public void deleteById(Long id) {
		// Delete client
		getClient(id);

		this.clientRepository.deleteById(id);
	}

	private void setDataClient(ClientDto clientDto, Client client) {
		client.setName(clientDto.getName());
		client.setDni(clientDto.getDni());
		client.setGender(clientDto.getGender());
		client.setAge(clientDto.getAge());
		client.setAddress(clientDto.getAddress());
		client.setPhone(clientDto.getPhone());
		client.setActive(clientDto.isActive());
	}

	private ClientDto returnResult(Client client) {
		client = this.clientRepository.save(client);
		return ClientDto.from(client);
	}

	private Client getClient(Long id) {
		Client client = this.clientRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Cliente", id));
		return client;
	}
}
