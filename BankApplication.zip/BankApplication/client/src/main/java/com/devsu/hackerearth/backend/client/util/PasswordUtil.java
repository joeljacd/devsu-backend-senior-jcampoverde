package com.devsu.hackerearth.backend.client.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class PasswordUtil {
    
    private static final String CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	private static final int LENGTH_PASSWORD = 12;
	private static final SecureRandom RANDOM = new SecureRandom();

    public static String generatePassword(){
		StringBuilder sb = new StringBuilder(LENGTH_PASSWORD);
		for(int i= 0; i < LENGTH_PASSWORD; i++){
			sb.append(CHARS.charAt(RANDOM.nextInt(CHARS.length())));
		}

		return sb.toString();
	}

    public static String hash(String raw) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256")
                    .digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

}
