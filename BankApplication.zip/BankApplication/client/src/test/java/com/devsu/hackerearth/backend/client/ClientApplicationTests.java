package com.devsu.hackerearth.backend.client;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.client.exception.DuplicateResourceException;
import com.devsu.hackerearth.backend.client.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.service.ClientService;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase
@Transactional
class ClientApplicationTests {

	private static final String URL = "/api/clients";

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private ClientService service;

	// @Test
	// void contextLoads() {
	// }
	private ClientDto buildDtop(Long id) {
		ClientDto dto = new ClientDto();
		dto.setId(id);
		dto.setDni("0987654322");
		dto.setName("Joel Campoverde");
		dto.setGender("M");
		dto.setAge(30);
		dto.setAddress("Ac Principal Prueba 123");
		dto.setPhone("0999876543");
		dto.setActive(true);

		return dto;
	}

	@Test
	void getAll_toData() throws Exception {
		when(service.getAll()).thenReturn(Arrays.asList(buildDtop(1L), buildDtop(2L)));

		mockMvc.perform(get(URL))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.length()").value(2))
				.andExpect(jsonPath("$[0].id").value(1));
	}

	@Test
	void getAll_notData() throws Exception {
		when(service.getAll()).thenReturn(Collections.emptyList());

		mockMvc.perform(get(URL))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$").isEmpty());
	}

	@Test
	void getById_toData() throws Exception {
		when(service.getById(1L)).thenReturn(buildDtop(1L));

		mockMvc.perform(get(URL + "/{id}", 1L))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.id").value(1))
				.andExpect(jsonPath("$.dni").value("0987654322"));
	}

	@Test
	void getById_notFound() throws Exception {
		when(service.getById(99L)).thenThrow(new ResourceNotFoundException("Cliente", 99L));

		mockMvc.perform(get(URL + "/{id}", 99L))
				.andExpect(status().isNotFound());
	}

	@Test
	void create_ok() throws Exception {
		when(service.create(any(ClientDto.class))).thenReturn(buildDtop(1L));

		mockMvc.perform(post(URL)
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(buildDtop(null))))
				.andExpect(status().isCreated())
				.andExpect(header().string("Location", "/api/clients/1"))
				.andExpect(jsonPath("$.id").value(1));
	}

	@Test
	void create_badRequest() throws Exception {
		ClientDto dto = buildDtop(null);
		dto.setName("");

		mockMvc.perform(post(URL)
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(dto)))
				.andExpect(status().isBadRequest());
	}

	@Test
	void create_duplicate() throws Exception {
		when(service.create(any(ClientDto.class)))
				.thenThrow(new DuplicateResourceException("Ya existe un cliente con DNI: 0987654322"));

		mockMvc.perform(post(URL)
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(buildDtop(null))))
				.andExpect(status().isConflict());
	}

	@Test
	void update_ok() throws Exception {
		when(service.update(any(ClientDto.class))).thenReturn(buildDtop(5L));

		mockMvc.perform(put(URL + "/{id}", 5L)
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(buildDtop(null))))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.id").value(5));
	}

	@Test
	void update_notFound() throws Exception {
		when(service.update(any(ClientDto.class))).thenThrow(new ResourceNotFoundException("Cliente", 99L));

		mockMvc.perform(put(URL + "/{id}", 99L)
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(buildDtop(null))))
				.andExpect(status().isNotFound());
	}

	@Test
	void partialUpdate_ok() throws Exception {
		when(service.partialUpdate(eq(1L), any(PartialClientDto.class))).thenReturn(buildDtop(1L));
		String body = objectMapper.writeValueAsString(new PartialClientDto(false));

		mockMvc.perform(patch(URL + "/{id}", 1L)
				.contentType(MediaType.APPLICATION_JSON)
				.content(body))
				.andExpect(status().isOk());
	}

	@Test
	void delete_ok() throws Exception {
		mockMvc.perform(delete(URL + "/{id}", 1L))
				.andExpect(status().isNoContent());

		verify(service).deleteById(1L);
	}

	@Test
	void delete_notFound() throws Exception {
		doThrow(new ResourceNotFoundException("Cliente", 99L)).when(service).deleteById(99L);

		mockMvc.perform(delete(URL + "/{id}", 99L))
				.andExpect(status().isNotFound());
	}

}
