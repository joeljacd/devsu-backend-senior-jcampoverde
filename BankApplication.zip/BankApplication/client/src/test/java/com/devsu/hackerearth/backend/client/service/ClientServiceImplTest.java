package com.devsu.hackerearth.backend.client.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.devsu.hackerearth.backend.client.exception.DuplicateResourceException;
import com.devsu.hackerearth.backend.client.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@ExtendWith(MockitoExtension.class)
class ClientServiceImplTest {

    @Mock
    private ClientRepository repository;

    @InjectMocks
    private ClientServiceImpl service;

    @Test
    void create_dniDuplicate() {
        ClientDto data = new ClientDto();
        data.setDni("09876543210");

        when(repository.existsByDni("09876543210")).thenReturn(true);
        assertThrows(DuplicateResourceException.class, () -> service.create(data));
        verify(repository, never()).save(any());
    }

    @Test
    void create_ok() {
        ClientDto data = new ClientDto();
        data.setDni("09876543211");
        data.setName("Joel");
        data.setAge(30);
        data.setGender("M");

        when(repository.existsByDni("09876543211")).thenReturn(false);
        when(repository.save(any(Client.class))).thenAnswer(v -> v.getArgument(0));

        ClientDto result = service.create(data);

        assertEquals("09876543211", result.getDni());
        verify(repository).save(any(Client.class));
    }

    @Test
    void getById_notExists() {
        when(repository.findById(10L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(10L));
    }

}
